CREATE FUNCTION sys.extract_schema_from_file_name(path VARCHAR(512))
  RETURNS VARCHAR(64)
  BEGIN RETURN LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(REPLACE(path, '\', '/'), '/', -2), '/', 1), 64); END
;
