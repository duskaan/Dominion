CREATE PROCEDURE dreamhome.Count()
  BEGIN
Select Count(tblOrder) From tblOrder;


END;
