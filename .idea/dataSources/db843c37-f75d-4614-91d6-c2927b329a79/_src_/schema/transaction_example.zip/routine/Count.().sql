CREATE PROCEDURE transaction_example.Count()
  BEGIN
Select Count(tblorder.id) From tblorder;

END;
